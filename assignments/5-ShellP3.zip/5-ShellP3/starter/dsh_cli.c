#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "dshlib.h"

int main()
{
    return exec_local_cmd_loop();
}